package com.mphasis.mytravel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyTravelBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
