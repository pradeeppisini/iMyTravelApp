package com.mphasis.mytravel.model;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "place_suggestion")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PlaceSuggestion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    private String placeName;
    private String placeCategory;
    private String placeDescription;

    // Constructors, getters, and setters
}
