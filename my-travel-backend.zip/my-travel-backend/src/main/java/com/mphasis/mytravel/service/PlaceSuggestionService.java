package com.mphasis.mytravel.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.mytravel.model.PlaceSuggestion;
import com.mphasis.mytravel.repository.PlaceSuggestionRepository;

import java.util.List;

@Service
public class PlaceSuggestionService {
    private final PlaceSuggestionRepository placeSuggestionRepository;

    @Autowired
    public PlaceSuggestionService(PlaceSuggestionRepository placeSuggestionRepository) {
        this.placeSuggestionRepository = placeSuggestionRepository;
    }

    public List<PlaceSuggestion> getAllPlaceSuggestions() {
        return placeSuggestionRepository.findAll();
    }

    public PlaceSuggestion getPlaceSuggestionById(Long id) {
        return placeSuggestionRepository.findById(id).orElse(null);
    }

    public PlaceSuggestion savePlaceSuggestion(PlaceSuggestion placeSuggestion) {
        return placeSuggestionRepository.save(placeSuggestion);
    }

    public void deletePlaceSuggestion(Long id) {
        placeSuggestionRepository.deleteById(id);
    }
}
