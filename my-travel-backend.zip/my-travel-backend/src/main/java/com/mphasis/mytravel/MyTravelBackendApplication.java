package com.mphasis.mytravel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyTravelBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyTravelBackendApplication.class, args);
	}

}
